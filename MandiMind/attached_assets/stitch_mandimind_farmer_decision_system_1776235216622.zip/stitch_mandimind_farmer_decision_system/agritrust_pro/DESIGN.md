# Design System Strategy: The Editorial Harvest

## 1. Overview & Creative North Star
This design system is built upon the Creative North Star of **"The Digital Steward."** 

We are moving away from the "utilitarian app" aesthetic common in agritech and toward a high-end editorial experience that conveys authority, dignity, and calm. This is achieved through **Organic Brutalism**: combining the strength of heavy, bold typography with the warmth of an organic, cream-based palette. The layout rejects the standard "boxed-in" grid in favor of breathing room and tonal layering, making the complex data of crop pricing feel like a premium, curated insight rather than a cluttered spreadsheet.

## 2. Colors: Tonal Depth & The "No-Line" Rule
The palette is rooted in the earth—deep forest greens and sun-ripened golds. We use these not just as accents, but as structural elements.

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders to define sections. We define boundaries through background color shifts. A `surface-container-low` section sitting on a `surface` background provides all the separation a user needs without adding visual "noise."

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers—like stacked sheets of fine handmade paper.
*   **Base Layer:** `surface` (#fff9eb) - The foundational canvas.
*   **Section Layer:** `surface-container-low` (#faf3e0) - Large content blocks.
*   **Interaction Layer:** `surface-container-lowest` (#ffffff) - Actionable cards or input zones.
*   **Nesting:** Place a white `surface-container-lowest` card inside a `surface-container-low` section to create a soft, natural lift.

### Glass & Gradient Rules
To provide visual "soul," use subtle gradients for primary CTAs transitioning from `primary` (#004c22) to `primary_container` (#166534). For floating elements (like a "Price Alert" snackbar), use **Glassmorphism**: semi-transparent `surface` colors with a 12px backdrop-blur to allow the background hues to bleed through, softening the interface.

## 3. Typography: The Editorial Voice
We use a high-contrast sans-serif pairing to ensure legibility in high-glare outdoor environments (fields).

*   **Display & Headlines (Manrope):** These are our "anchors." They must be bold and oversized to convey authority. `display-md` (2.75rem) should be used for critical price numbers.
*   **Titles & Body (Be Vietnam Pro):** Chosen for its exceptional geometric clarity. 
    *   **Minimum Body Size:** Never drop below `body-lg` (16px) for farmer-facing content.
    *   **The Hierarchy:** Use `title-lg` for crop names to give them "hero" status.

## 4. Elevation & Depth: Tonal Layering
We do not use shadows to create "fake" 3D. We use light and tone.

*   **The Layering Principle:** Depth is achieved by "stacking" tiers. A `surface-container-highest` element indicates the most urgent information, naturally "floating" above the `surface`.
*   **Ambient Shadows:** If a floating action button (FAB) is required, use an extra-diffused shadow: `blur: 24px`, `opacity: 6%`, using the `on-surface` color (#1e1c10) as the shadow tint.
*   **The Ghost Border Fallback:** If accessibility requires a container edge, use a "Ghost Border": `outline-variant` at 15% opacity. Never use 100% opaque lines.

## 5. Components: Precision & Thumb-First Ergonomics

### Buttons (The "Power" Action)
*   **Primary:** Full-width (min 56px height), `primary` background, `on-primary` text. Use a `md` (0.75rem) corner radius.
*   **Secondary/Hold:** Used for "Wait/Hold" decisions. `secondary_container` (#feb234) with `on-secondary-container` (#6d4700). 
*   **Tertiary:** No background, `primary` bold text with an icon.

### Cards & Lists (The "No Divider" Rule)
*   **Forbid dividers.** To separate two list items, use 16px of vertical white space or a subtle shift between `surface-container-low` and `surface-container-high`.
*   **Content Limit:** Max 3 elements per card (e.g., Crop Name, Price, Trend Trend).

### Input Fields & Dropdowns
*   **Height:** Minimum 64px to accommodate large "thumb" taps.
*   **Labels:** Always visible, never floating placeholders.
*   **Dropdowns:** Use full-screen bottom sheets instead of small pop-over menus to maintain the mobile-first "thumb-friendly" philosophy.

### Additional Signature Components
*   **Price Pulse:** A large, `secondary` (#815500) highlighted chip showing "Sell" or "Hold" status with high-contrast text.
*   **The Decision Gauge:** A horizontal bar using `primary` and `secondary` to show market sentiment, avoiding thin lines in favor of 8px thick "blocks."

## 6. Do's and Don'ts

### Do
*   **Do** prioritize verticality. Use a single-column layout exclusively.
*   **Do** use labels with every icon. A "Market" icon must have the word "Market" beneath it in `label-md`.
*   **Do** embrace "White Space." If a screen feels full, remove an element rather than shrinking the text.

### Don't
*   **Don't** use 1px lines. They create visual "vibration" and look cheap.
*   **Don't** use standard blue for links. Use `primary` (Deep Green) or `secondary` (Gold).
*   **Don't** use "Small" or "Extra Small" typography. If it’s worth putting on the screen, it’s worth being readable at arm's length in a field.